<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer classes
require 'path/to/PHPMailer/src/Exception.php';
require 'path/to/PHPMailer/src/PHPMailer.php';
require 'path/to/PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    // Email address where the form data will be sent
    $to = "astproductions9@gmail.com";

    // Create a PHPMailer object
    $mail = new PHPMailer(true);

    try {
        // Set mailer to use SMTP
        $mail->isSMTP();
        // Enable verbose debug output
        $mail->SMTPDebug = SMTP::DEBUG_OFF; // You can set it to DEBUG_SERVER for debugging
        // Set the server details
        $mail->Host = 'your-smtp-server.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your-smtp-username';
        $mail->Password = 'your-smtp-password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Use PHPMailer::ENCRYPTION_SMTPS for secure connection
        $mail->Port = 587; // Use 465 for secure connection

        // Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress($to);

        // Content
        $mail->isHTML(false); // Set to true if your message is HTML
        $mail->Subject = "New Contact Form Submission: $subject";
        $mail->Body = "You have received a new contact form submission.\n\n"
            . "Name: $name\n"
            . "Email: $email\n"
            . "Subject: $subject\n"
            . "Message:\n$message";

        // Send the email
        $mail->send();
        echo "Thank you for your message. We will get back to you soon.";
    } catch (Exception $e) {
        echo "Sorry, something went wrong. Please try again later. Error: " . $mail->ErrorInfo;
    }
} else {
    // If the request is not a POST request, redirect to the home page or display an error message.
    header("Location: index.html"); // Replace with the actual home page URL
    exit();
}
?>
<?php
phpinfo();
?>

